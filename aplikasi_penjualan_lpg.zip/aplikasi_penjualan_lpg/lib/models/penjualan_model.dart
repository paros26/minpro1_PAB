class Penjualan {
  String nik;
  String nama;
  int jumlah;
  String tanggal;

  Penjualan({
    required this.nik,
    required this.nama,
    required this.jumlah,
    required this.tanggal,
  });
}