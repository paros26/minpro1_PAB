class Pelanggan {
  String nik;
  String nama;
  String kategori;

  Pelanggan({
    required this.nik,
    required this.nama,
    required this.kategori,
  });
}