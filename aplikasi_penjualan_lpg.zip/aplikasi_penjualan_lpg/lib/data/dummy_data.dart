List<Map<String, dynamic>> pelangganList = [];
List<Map<String, dynamic>> penjualanList = [];

// 🔥 stok awal
int stokTabung = 50;