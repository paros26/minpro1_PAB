package com.example.aplikasi_penjualan_lpg

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
